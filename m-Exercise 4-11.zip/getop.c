#include <ctype.h>
#include <stdio.h>
#include "calc.h"

int getop(char s[]) {
    int i = 0;
    int c;
    static int last = ' ';

    while (last == ' ' || last == '\t')
        last = getchar();

    c = last;
    s[i++] = c;
    s[i] = '\0';

    if (!isdigit(c) && c != '.') {
        last = ' ';
        return c;
    }

    if (isdigit(c)) {
        while (isdigit(s[i++] = c = getchar()))
            ;
    }

    if (c == '.') {
        while (isdigit(s[i++] = c = getchar()))
            ;
    }

    s[i - 1] = '\0';
    last = c;
    return NUMBER;
}
