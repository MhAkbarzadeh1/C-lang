#define MAXVAL 100
#define BUFSIZE 100
#define NUMBER '0'

int getop(char []);
void push(double);
double pop(void);
int getch(void);
void ungetch(int);
